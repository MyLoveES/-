#include "../include/GV.h"

void graph_ch(){
	DrawRotaGraphF(ch.x,ch.y,1.0f,0.0f,img_ch[0][ch.img],TRUE);
}

void graph_main(){
	graph_ch();
}