#define GLOBAL_INSTANCE 
#include "../include/GV.h"
