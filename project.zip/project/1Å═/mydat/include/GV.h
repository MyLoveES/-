#include "../../../include/DxLib.h"
#include "define.h"