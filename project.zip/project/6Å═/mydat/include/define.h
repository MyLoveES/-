#include "struct.h"

#define FIELD_MAX_X 384
#define FIELD_MAX_Y 448