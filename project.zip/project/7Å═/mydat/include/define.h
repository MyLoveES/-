#include "struct.h"

#define FIELD_MAX_X 384
#define FIELD_MAX_Y 448

#define FIELD_X 32
#define FIELD_Y 16
