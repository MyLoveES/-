#include "../include/GV.h"

void calc_ch(){
	ch.cnt++;
	ch.img=(ch.cnt%24)/6;
}