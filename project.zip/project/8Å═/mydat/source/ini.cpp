#include "../include/GV.h"

//��ԍŏ��̏�����
void first_ini(){
	ch.x=FIELD_MAX_X/2;
	ch.y=FIELD_MAX_Y*3/4;

	configpad.down=0;
	configpad.left=1;
	configpad.right=2;
	configpad.up=3;
	configpad.bom=4;
	configpad.shot=5;
	configpad.slow=11;
	configpad.start=13;
	configpad.change=6;
}
